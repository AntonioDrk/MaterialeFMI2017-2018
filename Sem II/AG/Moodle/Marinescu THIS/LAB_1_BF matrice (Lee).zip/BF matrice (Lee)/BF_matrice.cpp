/*Iesire din labirint pe drumul minim*/
#include<fstream>
#include<queue>
#include<algorithm>
#include<list>
#include<iostream>
using namespace std;


struct pereche{
	int x,y;
};
 

 
void bordare(int n, int **lab){
	int i;
 
    for(i=0;i<=n+1;i++) {
   		lab[i][0]=-1;
   		lab[n+1][i]=-1;
   		lab[0][i]=-1;
   		lab[i][n+1]=-1;	
	}
 
}
 
void citire(int &n, int **&lab, pereche &start){
    int i,j;
	ifstream f("labirint.in");
	f>>n;
	lab = new int*[n+2];
	for (int i = 0; i <= n+1; i++)
		lab[i] = new int[n+2];
		
    for(i=1;i<=n;i++)
    	for(j=1;j<=n;j++)
			f>>lab[i][j];
		  		
	f>>start.x>>start.y;
	f.close();
}
 
int iesire(pereche p, int n){
	if(p.x==1 || p.x==n || p.y==1 || p.y==n)
		return 1;
	return 0;	
}

void afislant(pereche p, pereche **tata){
	if(p.x!=0 && p.y!=0){
		afislant(tata[p.x][p.y],tata);
		cout<<"("<<p.x<<","<<p.y<<") \n";
	}
}

pereche bfs(int n, int **lab, pereche start, pereche **&tata){
 
	int deplx[]={-1,1,0,0}; //initializare pentru avansare
	int deply[]={0,0,-1,1,};
    int i,j,x,y,vx,vy;
	int **viz;
    viz = new int*[n+2];
	for (int i = 1; i <= n+1; i++)
		viz[i] = new int[n+2];
		
	tata = new pereche*[n+2];
	for (int i = 1; i <= n; i++)
		tata[i] = new pereche[n+2];
		
	pereche zero={0,0};	
			
    for(i=1;i<=n;i++)
    	for(j=1;j<=n;j++)
    		viz[i][j]=0;
    		
     for(i=1;i<=n;i++)
    	for(j=1;j<=n;j++)		
    		tata[i][j]=zero;
    		
	queue<pereche> c;
	
    viz[start.x][start.y]=1;
    c.push(start);
    if(iesire(start, n))
			return start;
    while(!c.empty()){
        pereche celula_curenta=c.front(); //celula curenta
        c.pop();
        x=celula_curenta.x;
        y=celula_curenta.y;
        //cout<<x<<" "<<y<<endl;
        for(int i=0;i<4;i++){
			vx=x+deplx[i]; //vecinii celulei (x,y) vor fi (vx,vy)
			vy=y+deply[i];
			pereche celula_vecina;
			celula_vecina.x=vx;
			celula_vecina.y=vy;
            if(lab[vx][vy]==0 && viz[vx][vy]==0)//doar in celule libere nevizitate
            {
                tata[vx][vy]=celula_curenta; //perechea curenta
				viz[vx][vy]=1; //marcam celula
				if(iesire(celula_vecina,n))
					return celula_vecina;
                c.push(celula_vecina);
            }
        }
   }
   return zero;
}


 
 
int main()
{ 
    int **lab;
	pereche **tata;
	int n;
	pereche start, iesire;
	
	
	citire(n, lab, start);
 
	//bordam matricea cu 1 (perete) pentru a nu mai testa iesirea din matrice
	bordare(n,lab);

	//bfs-returneaza prima iesire care o gaseste + vectorul tata
	iesire=bfs(n,lab, start, tata);
 
	
 
	
	if(iesire.x!=0 && iesire.y!=0){
		cout<<"cea mai apropiata iesire este ("<<iesire.x<<","<<iesire.y<<")"<<endl;
		cout<<"un traseu minim pana la iesire este"<<endl;
		afislant(iesire, tata);
	}
	else
		cout<<"nu se poate iesi din labirint ";
	
	
}
