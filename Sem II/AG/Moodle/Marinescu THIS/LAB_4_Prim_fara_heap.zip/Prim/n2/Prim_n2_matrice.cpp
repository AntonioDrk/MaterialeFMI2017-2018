#include <fstream>
#include <iostream>
#include <algorithm>
#define infinit INT32_MAX
using namespace std;
struct muchie{
    int vi,vf;
    double cost;
};
void afiseaza(int n, int *r, ofstream &g){
	int k;
    for(k=1;k<=n;k++)
     	g<<r[k]<<"  ";
			
	g<<endl;	
}
void afiseazad(int n, double *r, ofstream &g){
	int k;
     for(k=1;k<=n;k++)
     	if(r[k]<infinit)
			g<<r[k]<<"  ";
		else
		    g<<"inf ";	
	g<<endl;	
}
void afis(muchie m, ofstream &g){
    g<<"("<<m.vi<<", "<<m.vf<<") cost "<<m.cost<<endl;
}

int minim(double *d, int *viz, int n){
	int u=-1;
	double dmin=infinit;
	for(int i=1;i<=n;i++)
		if(viz[i]==0 && d[i]<dmin){
			dmin=d[i];
			u=i;
		}
	return u;
}
void Prim(int s, int n, int **w,  vector<muchie> &muchii_apcm, ofstream &g){
	int u,  *tata, *viz,i,v;
	double *d;
	//*initializare d,tata,viz
	d=new double[n+1];
	tata=new int[n+1];
	viz=new int[n+1];
	
	for(u=1;u<=n;u++){
		viz[u]=tata[u]=0;
		d[u]=infinit;
	}
	d[s]=0;
	for(i=1;i<=n-1;i++){
		
		u=minim(d,viz,n);//varful nevizitat cu d minim
		viz[u]=1;
		g<<"extras "<<u<<endl;
		//actualizam etichetele vecinilor nevizitati
		for(v=1;v<=n;v++)
			if(w[u][v]<infinit && viz[v]==0) 
				if(d[v]>w[u][v]){
					d[v]=w[u][v];
					tata[v]=u;
				}
		g<<"d:   ";		
		afiseazad(n,d,g);	
		g<<"tata:";		
		afiseaza(n,tata,g);	
	}
	
	for(u=1;u<=n;u++)
		if(tata[u]!=0) //u!=s
			muchii_apcm.push_back({u,tata[u],d[u]});
}
int main(){
	fstream f("graf.in",ios::in);
	ofstream g("graf.out"); 
	int m,n, **w,x,y,c,i,j,s,mc;
	
	f>>n;
	f>>m;
	w=new int*[n+1];//graf- memorat cu matrice de costuri
	for(i=1;i<=n;i++)
		w[i]=new int[n+1];
	
	//initializam cu infinit si diagonala cu 0	
	for(i=1;i<=n;i++)
    	for(j=1;j<=n;j++)
    		w[i][j]=infinit;
    for(i=1;i<=n;i++)
    	w[i][i]=0;	
    	
    //citim muchiile	
	for(i=1;i<=m;i++){
		f>>x>>y>>c;
		w[x][y]=c;
		//neorientat
		w[y][x]=c;
	}
	f.close();
   
    
   
    vector<muchie> muchii_apcm;
    cout<<"Introduceti varful de start ";
    cin>>s;
    Prim(s,n,w,muchii_apcm,g);
   
 
    if (muchii_apcm.size()<n-1) g<<"graful nu este conex";
    else {
    	double cost=0;
    	g<<endl<<"muchiile arborelui partial optim:"<<endl;
    	for(mc=0;mc<muchii_apcm.size();mc++){
			afis(muchii_apcm[mc],g);
    		cost+=muchii_apcm[mc].cost;
    	}
    	g<<"cost total "<<cost;
	}
    g.close();
 
	return 0;

}

