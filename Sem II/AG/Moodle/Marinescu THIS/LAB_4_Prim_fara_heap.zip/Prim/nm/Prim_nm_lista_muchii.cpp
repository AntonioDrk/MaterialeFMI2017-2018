#include <fstream>
#include <iostream>
#include <algorithm>
#define infinit INT32_MAX
using namespace std;
struct muchie{
    int vi,vf;
    double cost;
};
void afiseaza(int n, int *r, ofstream &g){
	int k;
    for(k=1;k<=n;k++)
     	g<<r[k]<<"  ";
			
	g<<endl;	
}
void afiseazad(int n, double *r, ofstream &g){
	int k;
     for(k=1;k<=n;k++)
     	if(r[k]<infinit)
			g<<r[k]<<"  ";
		else
		    g<<"inf ";	
	g<<endl;	
}
void afis(muchie m, ofstream &g){
    g<<"("<<m.vi<<", "<<m.vf<<") cost "<<m.cost<<endl;
}


muchie muchie_minima( int m, muchie *muchii, int *viz){//muchia minima cu o extremitate vizitata si cealalta nu
	muchie m_min={0,0,0};
	int x,y;
	double costmin=infinit;
	for(int i=0;i<m;i++){
		muchie mcurent=muchii[i];
		x=mcurent.vi;
		y=mcurent.vf;
		if ( (viz[x]==0 && viz[y]==1 ) || (viz[x]==1 && viz[y]==0 )) //de la un varf vizitat la unul nevizitat
			if(mcurent.cost<costmin){
				costmin=mcurent.cost;
				m_min=mcurent;
			}
	}
	return m_min;
}

void Prim(int s, int n, int m, muchie *muchii,  vector<muchie> &muchii_apcm, ofstream &g){
	int u,  *viz,i,v;

	viz=new int[n+1];
	
	for(u=1;u<=n;u++)
		viz[u]=0;
	
	viz[s]=1;
	for(i=1;i<=n-1;i++){
		//este aleasa muchia minima cu o extremitate vizitata (deja in arbore) si cealalta nevizitata
		muchie m_min=muchie_minima(m,muchii,viz);
		
		//se adauga varful nevzitat si muchia la arbore
		muchii_apcm.push_back(m_min);
				
		viz[m_min.vi]=viz[m_min.vf]=1; //una era deja vizitata
			
	}
	
 
			
}
int main(){
	fstream f("graf.in",ios::in);
	ofstream g("graf.out"); 
 
	int m,n,mc,i,s;
	muchie *muchii;
	
	f>>n;
	f>>m;
	muchii=new muchie[m];//graf- memorat ca lista de muchii 
	for(i=0;i<m;i++)
		f>>muchii[i].vi>>muchii[i].vf>>muchii[i].cost;
	f.close();
   
    
   
    vector<muchie> muchii_apcm;
    cout<<"Introduceti varful de start ";
    cin>>s;
    Prim(s,n,m,muchii,muchii_apcm,g);
   
 
    if (muchii_apcm.size()<n-1) g<<"graful nu este conex";
    else {
    	double cost=0;
    	g<< "muchiile arborelui partial optim:"<<endl;
    	for(mc=0;mc<muchii_apcm.size();mc++){
			afis(muchii_apcm[mc],g);
    		cost+=muchii_apcm[mc].cost;
    	}
    	g<<"cost total "<<cost;
	}
    g.close();
 
	return 0;

}

