#include <vector>
#include <queue>
#include<fstream>
#include<iostream>
#define infinit INT32_MAX
using namespace std;

 
vector<int> sortare_topologica_bf(vector<pair<int,double>> *la, int *gin, int n){
 	vector<int> sort_top;
	queue<int> c;
	int x,y;
	//adaugam toate elementele cu grad intern 0 in coada c
 	for(int i=1;i<=n;i++)
		if(gin[i]==0)
			c.push(i);
	
		
	while(!c.empty()){
		x=c.front();
		c.pop();
		 
		sort_top.push_back(x);
		
		for(int i=0;i<la[x].size();i++){
				int y=la[x][i].first;
				gin[y]--;
				if(gin[y]==0)
					c.push(y);
			}	
	}
	return sort_top;
}
void drum_minim_dag(vector<pair<int,double>> *la, int s, int *gin, int n){
    int *d=new int[n+1], *tata=new int[n+1];
    int x,y;
    vector<int> sort_top =sortare_topologica_bf(la,gin,n);
    
    for(int i=1;i<=n;i++){
		tata[i]=0;
    	d[i]=infinit;
	}
	 
	d[s]=0;
	
	cout<<"ordinea topologica (in care se calculeaza etichetele): ";
	for(int i=0;i<sort_top.size();i++){
		x=sort_top[i]; 
		cout<<x<<" ";
		for(int i=0;i<la[x].size();i++){
			y=la[x][i].first;
			if(d[y]>d[x]+la[x][i].second){
				d[y]=d[x]+la[x][i].second;
				tata[y]=x;
			}
		}
	}
	cout<<endl;
	cout<<"Vectorul de distante "<<endl;
	
	for(int i=1;i<=n;i++)
		if(d[i]==infinit)
			cout<<"inf ";
		else	
			cout<<d[i]<<" ";
	cout<<endl;	 	
	
	cout<<"Vectorul de tati (predecesori) "<<endl;
	
	for(int i=1;i<=n;i++)
		cout<<tata[i]<<" ";		
    
}


int main(){
    ifstream f("dag.in");
	ofstream g("dag.out");
	 
	int m,n, x,y,c,i,j,s,mc;
	int *gin;
	vector<pair<int,double>> *la;
	f>>n;
	f>>m;
	gin=new int[n+1];
	la=new vector<pair<int,double>>[n+1];//graf- memorat cu liste de adiacenta
  	
  	for(i=1;i<=n;i++)
  		gin[i]=0;
    	
    //citim muchiile	
	for(i=1;i<=m;i++){
		f>>x>>y>>c;
		la[x].push_back(make_pair(y,c));
		gin[y]++;
 
	}
	//punctul de start
	f>>s;
	f.close();
    
	drum_minim_dag(la,s,gin,n);
    
     
   
     return 0;   
}
