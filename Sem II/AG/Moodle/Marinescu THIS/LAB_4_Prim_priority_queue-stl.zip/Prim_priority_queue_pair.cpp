#include <fstream>
#include <iostream>
#include <algorithm>
#include <queue>
#define infinit INT32_MAX
using namespace std;
//struct muchie{
//    int vi,vf;
//    double cost;
//};
//struct muchie_min_varf{
//	int varf;
//	double d;
//	bool operator <(const muchie_min_varf &mv) const{ //implicit max-heap-invers compararea
//        return (d > mv.d);
//    }
//
//};


void afiseaza(int n, int *r, ofstream &g){
	int k;
    for(k=1;k<=n;k++)
     	g<<r[k]<<"  ";
			
	g<<endl;	
}
void afiseazad(int n, double *r, ofstream &g){
	int k;
     for(k=1;k<=n;k++)
     	if(r[k]<infinit)
			g<<r[k]<<"  ";
		else
		    g<<"inf ";	
	g<<endl;	
}
void afis(pair<pair<int,int>,double> m, ofstream &g){
    g<<"("<<m.first.first<<", "<<m.first.second<<") cost "<<m.second<<endl;
}




void Prim(int s, int n, vector<pair<int,double>> *la,  vector<pair<pair<int,int>,double>> &muchii_apcm, ofstream &g){
	int u,  *tata, *viz,i,v,j;
	double *d,w_uv;
	
	/*Q - priority_queue - nu permite actualizarea cheii unui element => se readauga un varf in Q de cate ori i se actualizeaza eticheta; 
	cand este extras un varf din Q -vecinii ii sunt procesati doar daca este prima data cand este extras din Q varful
	*/
	
	/*Q - set (arbore binar de cautare - inserare, cautare, stergere - complexitate logaritmica)
	spre deosebire de priority_queue, are metoda de cautare => nu inserez de mai multe ori in Q un varf */
	
		
	/*Q- heap propriu + un avem vector de pozitie in Q pentru fiecare element, pentru a sti unde trebuie reparat heapul
	nu mai necesita cautarea varfului sau reinserarea in Q*/ 
		
	//*initializare d,tata,viz
	d=new double[n+1];
	tata=new int[n+1];
	viz=new int[n+1];
	
	for(u=1;u<=n;u++){
		viz[u]=tata[u]=0;
		d[u]=infinit;
	}
	d[s]=0;
	
    //priority_queue <muchie_min_varf> Q;
    
	priority_queue <pair<double,int>> Q; //pereche {-d[u],u} - distanta cu -, pentru a se comporta ca min-heap
	Q.push({-d[s],s}); //suficient sa inseram in Q doar varful de start, nu toate varfurile, pentru ca nu facem actualizarea etichetei, ci stergere+reinserare
	while(!Q.empty()){  
		
		u=Q.top().second;//varful nevizitat cu d minim
	    Q.pop();
		viz[u]++;
		
		 
		//daca este prima extragere din Q a lui u actualizam etichetele vecinilor nevizitati
		if(viz[u]==1){
		    g<<"extras "<<u <<endl;
			for(j=0;j<la[u].size();j++){
			    v=la[u][j].first;
			    w_uv=la[u][j].second;  
				if(viz[v]==0) {
					if(d[v]>w_uv){
						tata[v]=u;
						d[v]=w_uv;
	  				    Q.push(make_pair(-d[v],v)); //adaug noua pereche v,d[v]
	  				}
				}
		    }	
			g<<"d:   ";		
			afiseazad(n,d,g);	
			g<<"tata:";		
			afiseaza(n,tata,g);	
		}
	}
	
	for(u=1;u<=n;u++)
		if(tata[u]!=0) //u!=s
			muchii_apcm.push_back(make_pair(make_pair(u,tata[u]),d[u]));
}
int main(){
	fstream f("graf.in",ios::in);
	ofstream g("apcm.out"); 
	int m,n, x,y,c,i,j,s,mc;
	vector<pair<int,double>> *la;
	f>>n;
	f>>m;
	la=new vector<pair<int,double>>[n+1];//graf- memorat cu liste de adiacenta
  	
    	
    //citim muchiile	
	for(i=1;i<=m;i++){
		f>>x>>y>>c;
		la[x].push_back(make_pair(y,c));
		la[y].push_back(make_pair(x,c));
	}
	f.close();
   
    
   
    vector<pair<pair<int,int>,double>> muchii_apcm;
    cout<<"Introduceti varful de start ";
    cin>>s;
    Prim(s,n,la,muchii_apcm,g);
   
 
    if (muchii_apcm.size()<n-1) g<<"graful nu este conex";
    else {
    	double cost=0;
    	g<<endl<<"muchiile arborelui de cost minim:"<<endl;
    	for(mc=0;mc<muchii_apcm.size();mc++){
			afis(muchii_apcm[mc],g);
    		cost+=muchii_apcm[mc].second;
    	}
    	g<<"cost total "<<cost;
	}
    g.close();
 
	return 0;

}

