#include <fstream>
#include <iostream>
#include <algorithm>
using namespace std;


void afiseaza(int n, int *r, ofstream &g){
	int k;
     for(k=1;k<=n;k++)
		g<<r[k]<<" ";
	g<<endl;	
}

struct muchie{
    int vi,vf;
    double cost;
    
};

void afis(muchie m, ofstream &g){
    g<<"("<<m.vi<<", "<<m.vf<<") cost "<<m.cost<<endl;
}

//--------KRUSKAL

void Initial(int u, int *tata, int *h)
{
        tata[u]=h[u]=0;
}


/*fara compresie de cale
int Reprez(int u)
{
    while(tata[u]!=0)
       u=tata[u];
    return u;  
}*/

//cu compresie de cale
int Reprez(int u, int *tata ){
  if (tata[u]==0) 
	return u;
  tata[u]=Reprez(tata[u], tata);   
  return tata[u];
}

//reuniune ponderata - dupa inaltimea h 
void Reuneste(int u,int v, int *tata, int *h)
{
    int ru,rv;
	ru=Reprez(u,tata);
	rv=Reprez(v,tata);
	if (h[ru]>h[rv])
		tata[rv]=ru;
	else{
		tata[ru]=rv;
		if(h[ru]==h[rv])
			h[rv]=h[rv]+1;

	}
	
}



int comp(muchie x, muchie y){
	if(x.cost<y.cost)
		return 1;
	return 0;	
}

void kruskal(int n, int m, muchie *muchii, vector<muchie> &muchii_apcm,ofstream &g){ 

    int nrmsel, mc,*tata,*h,u,v,i;
    
    //structura de date folosita-paduri de multimi disjuncte
    tata=new int[n+1];
    h=new int[n+1];
    
    //initializarea componenetelor 
  	for(v=1;v<=n;v++) 
		Initial(v,tata,h);
  
    nrmsel=0;//numarul de muchii deja selectate;
    mc=0;//indicele muchiei curente

    //initial muchiile se sorteaza crescator dupa cost
    sort(muchii,muchii+m, comp);
   
    g<<"muchii sortate dupa cost:"<<endl;
    for(i=0;i<m;i++) 
		afis(muchii[i],g);

    //while(mc<m && nrmsel<n-1){
	for(mc=0;mc<m;mc++)
	{
		g<<"muchia curenta: ";
		afis(muchii[mc],g);
		u=muchii[mc].vi;
		v=muchii[mc].vf;
	     
		if (Reprez(u,tata)!=Reprez(v, tata)){  //muchia uneste doua componente diferite
	    	nrmsel++;
	    	muchii_apcm.push_back(muchii[mc]);
	     
	        Reuneste(u,v,tata,h);
	        if(nrmsel==n-1)
	            break;
		}
		g<<"tata:" ;
        afiseaza(n,tata,g); //pentru a urmari evolutia padurilor disjuncte
        g<<"h   :" ;
        afiseaza(n,h,g);
    }
    g<<"tata:" ;
    afiseaza(n,tata,g); //pentru a urmari evolutia padurilor disjuncte
    g<<"h   :" ;
    afiseaza(n,h,g);
   
}

int main(){
	fstream f("kruskal.in",ios::in);
	ofstream g("kruskal_p.out"); 
	int m,n,mc,i;
	muchie *muchii;
	
	f>>n;
	f>>m;
	muchii=new muchie[m];//graf- memorat ca lista de muchii 
	for(i=0;i<m;i++)
		f>>muchii[i].vi>>muchii[i].vf>>muchii[i].cost;
	f.close();
   
    vector<muchie> muchii_apcm;
    kruskal(n,m,muchii,muchii_apcm,g);
   
 
    if (muchii_apcm.size()<n-1) g<<"graful nu este conex";
    else {
    	double cost=0;
    	g<<endl<<"muchiile arborelui partial optim:"<<endl;
    	for(mc=0;mc<muchii_apcm.size();mc++){
			afis(muchii_apcm[mc],g);
    		cost+=muchii_apcm[mc].cost;
    	}
    	g<<"cost total "<<cost;
	}
    g.close();
 
	return 0;

}

