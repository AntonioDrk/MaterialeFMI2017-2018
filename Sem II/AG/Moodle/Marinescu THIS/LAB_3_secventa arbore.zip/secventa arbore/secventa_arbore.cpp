#include<iostream>
#include<list>
#include<queue>
#include<fstream>
using namespace std;
struct varf{
	int grad;
	int eticheta;
};
 
 /*constructia unui arbore cu secventa de grade data
 idee- la un pas unim un varf care tb sa aiba grad 1 (terminal)
 cu unul care tb sa aiba grad>1
 In final raman 2 varfuri de grad 1 pe care le unim
 exp -v. slide curs 3*/
 
 /*Idee implementare - memoram doua liste: T  cu varfuri terminale, NT cu neterminale
 la un pas: unim un element din T cu unul din NT si scadem gradele lor
 daca elementul din NT devine terminal il mutam in T
 in final raman 2 varfuri in T pe care le unim
 */
int main(){
	int x,n,i;  
	queue<varf> T;// coada cu terminale 
	queue<varf > NT;//coada cu varfuri neterminale  
	
	ifstream fin("date.in");
	ofstream fout("date.out");
	fin>>n;//nr de varfuri
	int sum=0;
	for(i=1;i<=n;i++)
	{
		fin>>x; 
		sum+=x;// suma gradelor
		if(x<=0)
		{
		    fout<<"Secventa nu poate fi secventa de grade pentru arbore"; return 0;
		}
		varf v={x,i}; //pereche grad,eticheta
 		if(x==1) T.push(v);//pun terminalele in lista corespunzatoare
		else NT.push(v);//respectiv neterminalele 
	}
	
	if(sum!=2*(n-1))
	{
		fout<<"Secventa nu poate fi secventa de grade pentru arbore"; return 0;
	} 
	while(!NT.empty()) //in final vor ramane doua varfuri terminale 
	{
	  		 
	    fout<<T.front().eticheta<<" " <<NT.front().eticheta<<endl;//muchie terminal-neterminal
	    T.pop(); //elimin varful terminal
	    NT.front().grad--; //scad gradul varfului neterminal
	    
	    if(NT.front().grad==1 ) //mutam varful daca devine terminal in lista T
		{
			T.push(NT.front());
			NT.pop();//il eliminam din neterminale
		}
	    	
    }
    varf v1,v2;// in final in T vor mai fi 2 varfuri 
    v1=T.front(); 
	T.pop();
	v2=T.front(); 
	T.pop();// in final in T vor mai fi 2 varfuri 
    fout<<v1.eticheta<<" " <<v2.eticheta<<endl;//pe care le unim cu o muchie
    fin.close();
    fout.close();
    return 0;
	       
}
