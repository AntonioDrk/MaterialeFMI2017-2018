#include<fstream>
#include<vector>
#include<iostream>
#include<queue>
using namespace std;
void citire(int &n,vector<int> *&la, ifstream &f){
	int m,i,x,y;
	f>>n>>m;
	la=new vector<int>[n+1];
	for(i=1;i<=m;i++){
		f>>x>>y;
		la[x].push_back(y);
		//neorientat
		la[y].push_back(x);
	}
  
}


void afis(int n,vector<int> *la ){
	cout<<"Listele de adiacenta: "<<endl;
	int i,j;
	for(i=1;i<=n;i++){
		cout<<i<<": ";
		
		for(j=0;j<la[i].size();j++)
			cout<<la[i][j]<<" ";  
		cout<<endl;
       
        /*alte modalitati de parcurgere a vectorului la[i]
		for(int y:la[i])
			cout<<y<<" "; 
		for(vector<int>::iterator  it=la[i].begin(); it!= la[i].end();it++)	
			cout<<*it<<" ";
		*/	
	}
 	
}

void dfs(int x, vector<int> *la, int *viz, int *tata, int &ok){
	// cout<<x<<endl;
     viz[x]=1;
     for(int i=0;i<la[x].size() && ok==0 ;i++){
        int y=la[x][i];
		if (viz[y]==0){
			 tata[y]=x;	
             dfs(y,la,viz,tata,ok);
		}
         else
		 	if(y!=tata[x] ){
				cout<<"un ciclu elementar ";
				int v=x;
				while(v!=y){
					cout<<v<<" ";
					v=tata[v];
				}
				cout<<y<<" "<<x;
				ok=1;
		       
        	 }
	}
    
}



int main(){
	vector<int> *la;
	int n,m,s;
	int i,j;
	int *viz,*tata;
	ifstream f("graf.in");
	citire(n,la,f);
	f.close();
	afis(n,la);
	viz=new int[n+1];
	tata=new int[n+1];
	for(int i=1;i<=n;i++)
		viz[i]=tata[i]=0;
	int ok=0;
    for(int i=1;i<=n && ok==0;i++)
    	if(viz[i]==0)
    		dfs(i,la,viz,tata,ok);
	if(ok==0)
		cout<<"graf aciclic";
}
