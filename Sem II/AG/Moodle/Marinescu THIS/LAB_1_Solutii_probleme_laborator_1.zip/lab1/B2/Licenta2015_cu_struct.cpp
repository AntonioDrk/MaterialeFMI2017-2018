#include<fstream>
#include<queue>
#include<algorithm>
#include<list>
#include<iostream>
using namespace std;


struct pereche{
	int x,y;
};

int main()
{
	ifstream fin("graf.in");
	ofstream fout("graf.out");
	int n, m,x,y;
	
	
	
	//Pstart=vector cu coordonatele elementelor punctelor de start din graf.in
	//P1=vector cu coordonatele elementelor egale cu 1
	vector<pereche> Pstart, P1;
	

	pereche **dist;

	fin >> n >>  m;


   /*  dist[i][j]=pereche formata cu 
   		           -distanta de la de cel mai apropiat element egal cu 1 din matrice la la (i,j)
   		           -care este indicele acestui element egal cu 1 in P1/-1 daca nu a fost determinat
   	*/	           
	dist = new pereche*[n+1];
	for (int i = 1; i <= n; i++)
		dist[i] = new pereche[m+1];
		
	int k = 0; //indicele elementului curent din P1
	for(int i=1;i<=n;i++)
		for (int j = 1; j <=m; j++)
		{
			
			fin >> x;
			if (x==1) {
			    pereche e,de;
			    e.x=i;
				e.y=j; 
				P1.push_back(e); //e este adaugat pe pozitia k in P1
				
				de.x=0;
				de.y=k; 
				dist[i][j] = de;
				
				k++; 
			}
			else{
			    pereche de;
			 
				de.x=INT32_MAX;
				de.y=-1; 
				dist[i][j] = de;
			}

		}


	while (fin >> x >> y)
	{
		pereche e;
		e.x=x; e.y=y;
		Pstart.push_back(e);
	}
	   
	int deplx[]={1,-1,0,0};
	int deply[]={0,0,1,-1};
	
	queue<pereche> q;
	
	/*pornim parcurgerea simultan din toate punctele care au valoarea 1
	(ca si cum ar forma un singur varf, sau, mai exact, ca si cum ar exista o sursa fictiva adiacenta cu acestea
	din care porinim parcurgerea)
	*/
	for (int i = 0; i < k; i++)
		q.push(P1[i]); 
		
 	cout<<endl;
	while (!q.empty())	{
		int vx, vy;
	
		x = q.front().x;
		y = q.front().y;
 
	
		q.pop();
		for(int i=0;i<4;i++){
			vx=x+deplx[i]; //vecinii celulei (x,y) vor fi (vx,vy)
			vy=y+deply[i];
			
			if(vx>0 && vx<=n &&vy>0 && vy<=n)
				if(dist[vx][vy].y<0){ //este echivalent cu a testa ca celcula (vx,vy) este nevizitata
					//cout<<vx<<vy<<endl;
					dist[vx][vy].x=dist[x][y].x+1; //distanta de la ce a mai apropiata sursa (element=1) la (vx,vy) = 1+ cea pana la (x,y)
					dist[vx][vy].y=dist[x][y].y; //(vx,vy) preia din (x,y) si indicele celei mai apropiate surse
					pereche p;
					p.x=vx;
					p.y=vy;
					q.push(p);
				}
			
		} 
	}
 
	for (int i=0;i< Pstart.size();i++) 
	{
		pereche punctstart=Pstart[i];
		int sursaceamaiapropiata=dist[punctstart.x][punctstart.y].y;
		fout << dist[punctstart.x][punctstart.y].x << " " <<'['<< P1[sursaceamaiapropiata].x<<", "<< P1[sursaceamaiapropiata].y<<"]\n";
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
			cout << " (" << dist[i][j].x << " " << dist[i][j].y << ") ";
		cout << endl;
	}
 

		 
	fin.close(); fout.close();
	return 0;
}
