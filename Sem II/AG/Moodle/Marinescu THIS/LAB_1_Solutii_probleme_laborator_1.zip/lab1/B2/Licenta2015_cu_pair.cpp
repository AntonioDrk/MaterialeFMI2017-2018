#include<fstream>
#include<queue>
#include<algorithm>
#include<iostream>
using namespace std;


struct pereche{
	int x,y;
};

int main()
{
	ifstream fin("graf.in");
	ofstream fout("graf.out");
	int n, m,x,y;
	
	
	
	//Pstart=vector cu coordonatele elementelor punctelor de start din graf.in
	//P1=vector cu coordonatele elementelor egale cu 1
	
	//pair<int,int> in loc de pereche
	vector<pair<int,int>> Pstart, P1;
	

	pair<int,int> **dist;

	fin >> n >>  m;


   /*  dist[i][j]=pereche formata cu 
   		           -distanta de la de cel mai apropiat element egal cu 1 din matrice la la (i,j)
   		           -care este indicele acestui element egal cu 1 in P1/-1 daca nu a fost determinat
   	*/	           
	dist = new pair<int,int>*[n+1];
	for (int i = 1; i <= n; i++)
		dist[i] = new pair<int,int>[m+1];
		
	int k = 0; //indicele elementului curent din P1
	for(int i=1;i<=n;i++)
		for (int j = 1; j <=m; j++)
		{
			
			fin >> x;
			if (x==1) {
			    pair<int,int> e = make_pair(i,j);
			  	P1.push_back(e); //e este adaugat pe pozitia k in P1
				
				pair<int,int> de = make_pair(0,k);
				dist[i][j] = de;
				
				k++; 
			}
			else{
			    pair<int,int> de= make_pair(INT32_MAX, -1); 
				dist[i][j] = de;
			}

		}


	while (fin >> x >> y)
	{
		Pstart.push_back(make_pair(x,y));
	}
	   
	int deplx[]={1,-1,0,0};
	int deply[]={0,0,1,-1};
	
	queue<pair<int,int>> q;
	
	/*pornim parcurgerea simultan din toate punctele care au valoarea 1
	(ca si cum ar forma un singur varf, sau, mai exact, ca si cum ar exista o sursa fictiva adiacenta cu acestea
	din care porinim parcurgerea)
	*/
	for (int i = 0; i < k; i++)
		q.push(P1[i]);
	
	while (!q.empty())	{
		int vx, vy;
	
		x = q.front().first;
		y = q.front().second;
 
	
		q.pop();
		for(int i=0;i<4;i++){
			vx=x+deplx[i]; //vecinii celulei (x,y) vor fi (vx,vy)
			vy=y+deply[i];
			
			if(vx>0 && vx<=n &&vy>0 && vy<=n)
				if(dist[vx][vy].second<0){ //este echivalent cu a testa ca celcula (vx,vy) este nevizitata
					//cout<<vx<<vy<<endl;
					dist[vx][vy].first=dist[x][y].first+1; //distanta de la ce a mai apropiata sursa (element=1) la (vx,vy) = 1+ cea pana la (x,y)
					dist[vx][vy].second=dist[x][y].second; //(vx,vy) preia din (x,y) si indicele celei mai apropiate surse
				
					q.push(make_pair(vx,vy));
				}
			
		} 
	}
 
	for (int i=0;i< Pstart.size();i++) 
	{
		pair<int,int> punctstart=Pstart[i];
		int sursaceamaiapropiata=dist[punctstart.first][punctstart.second].second;
		fout << dist[punctstart.first][punctstart.second].first << " " <<'['<< P1[sursaceamaiapropiata].first<<", "<< P1[sursaceamaiapropiata].second<<"]\n";
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
			cout << " (" << dist[i][j].first << " " << dist[i][j].second << ") ";
		cout << endl;
	}
 
		 
	fin.close(); fout.close();
	return 0;
}
