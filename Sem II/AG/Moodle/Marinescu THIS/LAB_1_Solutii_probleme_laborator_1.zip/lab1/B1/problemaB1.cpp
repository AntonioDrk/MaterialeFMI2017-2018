#include<fstream>
#include<vector>
#include<iostream>
#include<queue>
using namespace std;
void citire(int &n,vector<int> *&la, int *&control, ifstream &f){
	int m,i,x,y;
	f>>n>>m;
	la=new vector<int>[n+1];
	for(i=1;i<=m;i++){
		f>>x>>y;
		la[x].push_back(y);
		//neorientat
		la[y].push_back(x);
	}
	control=new int[n+1];
	while(f>>x)
		control[x]=1;
}


void afis(int n,vector<int> *la, int *control){
	cout<<"Listele de adiacenta: "<<endl;
	int i,j;
	for(i=1;i<=n;i++){
		cout<<i<<": ";
		
		for(j=0;j<la[i].size();j++)
			cout<<la[i][j]<<" ";  
		cout<<endl;
       
        /*alte modalitati de parcurgere a vectorului la[i]
		for(int y:la[i])
			cout<<y<<" "; 
		for(vector<int>::iterator  it=la[i].begin(); it!= la[i].end();it++)	
			cout<<*it<<" ";
		*/	
	}
	cout<<"puncte de control: ";
	for(i=1;i<=n;i++)
		if(control[i]==1)
			cout<<i<<" ";
	cout<<endl;		
}
int BF(int s, int n, vector<int> *la, int *control, int *tata)
{
	int *viz=new int[n+1];
	queue<int> c;
		
	int i;
	for(i=1;i<=n;i++)
		viz[i]=0;
	
	tata[s]=0;	
	if(control[s]==1)
		return s;
						
	viz[s]=1;
	c.push(s);
	while(!c.empty()){
		int x=c.front();//x- nodul curent
		c.pop();
		for (i=0;i<la[x].size();i++){
			int y=la[x][i];//pentru toti vecinii y ai nodului curent x
			if(viz[y]==0)
				{ 
					tata[y]=x; 
					viz[y]=1;
					if(control[y]==1)//ne oprim la primul punct de control descoperit- este cel mai apropiat de punctul de start s
						return y;
					c.push(y);
				}
		}
	}
	return -1;
}

void afislant(int y, int *tata){
	if(y!=0){
		afislant(tata[y],tata);
		cout<<y<<" ";
	}
}
int main(){
	vector<int> *la;
	int n,m,s;
	int i,j;
	int *control,*tata;
	ifstream f("graf.in");
	citire(n,la,control,f);
	f.close();
	afis(n,la,control);
	cout<<"introduceti punctul de start ";
	cin>>s;
 
	tata=new int[n+1];
	int y=BF(s,n,la,control,tata);
	
	if(y!=-1){
		cout<<"cel mai apropiat punct de control de "<<s<<" este "<<y<<endl;
		cout<<"un lant minim intre cele doua varfuri este ";
		afislant(y,tata);
	}
	else
		cout<<"nu exista punct de control accesibil din "<<s;
}
